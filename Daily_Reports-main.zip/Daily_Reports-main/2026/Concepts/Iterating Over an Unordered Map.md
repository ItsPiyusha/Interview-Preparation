# Explaining `unordered_map<int,int> cnt;` frequency counting

`unordered_map<int,int> cnt;` is a hash map from **key → value**:

- **key**: the number `x` from `nums`
- **value**: how many times `x` appears (its frequency)

This code:

```cpp
unordered_map<int,int> cnt;
for (int x : nums) cnt[x]++;
```

means: “for each number `x` in `nums`, increase its count by 1”.

`cnt[x]` behavior:
- If `x` is **not** already a key in the map, `cnt[x]` is **created automatically** with value `0`.
- Then `++` increments it.

---

## Picture (conceptual)

Example: `nums = [5, 2, 5, 7, 2, 5]`

As we scan left to right:

```
Start: cnt = { }

Read 5  -> cnt[5] = 1      { 5:1 }
Read 2  -> cnt[2] = 1      { 5:1, 2:1 }
Read 5  -> cnt[5] = 2      { 5:2, 2:1 }
Read 7  -> cnt[7] = 1      { 5:2, 2:1, 7:1 }
Read 2  -> cnt[2] = 2      { 5:2, 2:2, 7:1 }
Read 5  -> cnt[5] = 3      { 5:3, 2:2, 7:1 }
```

Final map:

```
key (number)  -> value (count)
2             -> 2
5             -> 3
7             -> 1
```

(Being an `unordered_map`, the internal order is not sorted.)

---

## How to iterate over this map

### 1) Iterate key + value (most common)
```cpp
for (const auto& [key, value] : cnt) {
    cout << key << " occurs " << value << " times\n";
}
```

If you can’t use structured bindings:

```cpp
for (const auto& p : cnt) {
    cout << p.first << " occurs " << p.second << " times\n";
}
```

### 2) Iterate only keys
```cpp
for (const auto& [key, value] : cnt) {
    cout << "key = " << key << "\n";
}
```

### 3) Iterate only values
```cpp
for (const auto& [key, value] : cnt) {
    cout << "value = " << value << "\n";
}
```

### 4) Iterator style (explicit iterators)
```cpp
for (auto it = cnt.begin(); it != cnt.end(); ++it) {
    cout << it->first << " -> " << it->second << "\n";
}
```

---

## Ways to “track keys” or “track values”

### A) Just use the map (keys and values are already tracked)
- Keys: `p.first`
- Values: `p.second`

### B) Track keys separately (e.g., you need a stable list of keys)
```cpp
vector<int> keys;
for (int x : nums) {
    if (cnt[x] == 0) keys.push_back(x); // first time seeing x
    cnt[x]++;
}
```

Now `keys` contains each distinct number once (in *first-seen order*).

### C) Track values separately (less common; depends on what you need)
If you want all counts:

```cpp
vector<int> counts;
for (auto& [k, v] : cnt) counts.push_back(v);
```

### D) Check existence of a key without inserting it
Important: `cnt[x]` **inserts** if missing. If you only want to check:

```cpp
if (cnt.find(x) != cnt.end()) {
    // exists
}
```

or (C++20):

```cpp
if (cnt.contains(x)) {
    // exists
}
```

### E) Get a value safely (without inserting)
```cpp
auto it = cnt.find(x);
if (it != cnt.end()) {
    int val = it->second;
}
```

---

## Notes / gotchas

- `unordered_map` iteration order is arbitrary.
- If you need keys in sorted order, either:
  - copy keys to a vector and sort, or
  - use `map<int,int>` (ordered map) instead of `unordered_map<int,int>`.

