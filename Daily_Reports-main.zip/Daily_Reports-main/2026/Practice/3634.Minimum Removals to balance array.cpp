class Solution {
public:
    int minRemoval(vector<int>& nums, int k) {
         int n = (int)nums.size();
    sort(nums.begin(),nums.end());
    
    int l = 0;
    int best = 1;
    
    for(int r =0; r < n; ++r){
        while(l<=r && (long long)nums[r] > (long long)nums[l]*k){
            ++l;
        }
        best = max(best,r-l+1);
    }
    return n-best;   
    }
};
